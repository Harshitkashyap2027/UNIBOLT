---

### 💻 File 2: `OptimizedList.tsx` (Source Code)
*Save this as `OptimizedList.tsx` inside the folder.*

```tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { FlashList } from '@shopify/flash-list';
import Animated, { FadeInRight } from 'react-native-reanimated';

/**
 * UNIBOLT WORKSHOP DEMO
 * ---------------------
 * This component demonstrates rendering 10,000 items at 60 FPS
 * using FlashList and Reanimated layout animations.
 */

const DATA = Array.from({ length: 10000 }, (_, i) => ({
  title: `Item #${i + 1}`,
  description: 'Optimized list item with recycled views.',
}));

const ListItem = ({ item, index }) => {
  return (
    <Animated.View 
      entering={FadeInRight.delay(index * 10)} 
      style={styles.itemContainer}
    >
      <View style={styles.avatar} />
      <View style={styles.textContainer}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.desc}>{item.description}</Text>
      </View>
    </Animated.View>
  );
};

export default function OptimizedList() {
  return (
    <View style={styles.container}>
      <FlashList
        data={DATA}
        renderItem={({ item, index }) => <ListItem item={item} index={index} />}
        estimatedItemSize={70} // Critical for FlashList performance!
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f0f',
  },
  itemContainer: {
    height: 70,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#0ea5e9',
    marginRight: 15,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  desc: {
    color: '#888',
    fontSize: 12,
  },
});