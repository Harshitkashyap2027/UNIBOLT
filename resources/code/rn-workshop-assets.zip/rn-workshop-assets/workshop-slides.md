# ⚡ React Native Performance Optimization
**Hosted by UniBolt | Internal Workshop**

---

## 📅 Agenda
1. The "Old" Architecture (The Bridge)
2. The New Architecture (Fabric & TurboModules)
3. The Hermes Engine
4. Optimizing Lists (FlashList)
5. Animations (Reanimated 3)

---

## 1. The Bridge Problem
In the old architecture, all communication between JavaScript (Logic) and Native (UI) happened over an asynchronous JSON bridge.
* **Bottleneck:** Serialization/Deserialization is slow.
* **Impact:** Dropped frames during rapid scrolling or complex animations.

---

## 2. The Solution: JSI (JavaScript Interface)
JSI allows JavaScript to hold references to C++ Host Objects and invoke methods on them **synchronously**.
* **Fabric:** The new Rendering System (UI).
* **TurboModules:** The new Native Module system (Lazy loaded).

---

## 3. Hermes Engine 🚀
Hermes is an open-source JavaScript engine optimized for React Native.
* **Bytecode Precompilation:** JS is compiled to bytecode during the build, not at runtime.
* **Result:** * Start-up time: 2x faster.
    * App Size: ~40% smaller.
    * Memory: Lower usage.

**How to enable (android/app/build.gradle):**
`project.ext.react = [ enableHermes: true ]`

---

## 4. List Performance
**Avoid:** `FlatList` (Creates a new view for every item).
**Use:** `FlashList` (Recycles views efficiently).

| Metric | FlatList | FlashList |
| :--- | :--- | :--- |
| FPS on Low-end | 45 | 59 |
| Memory | High | Low |
| Render Time | 120ms | 14ms |

---

## 5. Animations
**Rule:** Never run animations on the JS thread.
**Tool:** `react-native-reanimated`

```javascript
// BAD (JS Thread)
Animated.timing(opacity, { toValue: 1 }).start();

// GOOD (UI Thread)
const style = useAnimatedStyle(() => {
  return { opacity: withTiming(1) };
});